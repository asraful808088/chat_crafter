from cat import ConditionTypes

def getCondition():
    return ConditionTypes.mama2



