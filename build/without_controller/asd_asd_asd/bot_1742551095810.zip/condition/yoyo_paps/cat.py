
from enum import Enum
class ConditionTypes(Enum):
    mama = "mama"
    mama2 = "mama2"


