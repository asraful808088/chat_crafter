from demos import mama    
def run_task(params,memo):

    # todo // 
    return {
        "memo":memo,
        "data":{
                "data":mama()
        }
    }

