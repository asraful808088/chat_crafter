def mama():
    return "ASDasdasdasdasda123123"


