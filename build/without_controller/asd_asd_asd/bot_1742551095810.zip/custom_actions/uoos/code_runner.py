# from task.yoyotask.code_runner import run_task
def run_task(memo={}):
    return {
                "memo":memo,
                "response":"asdasdasddasd123123132",
                "data":{}
    }
    # return {
    #             "memo":memo,
    #             "txt":"",
    # }
