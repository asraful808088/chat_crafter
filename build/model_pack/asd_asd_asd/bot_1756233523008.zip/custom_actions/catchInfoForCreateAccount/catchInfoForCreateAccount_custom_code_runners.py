from entities_box.xx.generated import predict_entities
def run_task(memo={}):
    # print(predict_entities)
    print(memo)
    return {
                "memo":memo,
                "txt":"user create successfully",
    }
